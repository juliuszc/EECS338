window.addEventListener("DOMContentLoaded",function(){kango._init("document-end")},!1);kango._init("document-start");
